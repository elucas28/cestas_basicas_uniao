# Cestas Básicas União - Chat Bot

Um chatbot estilo WhatsApp para processar pedidos de cestas básicas.

## Requisitos

- Python 3.8+
- Flask
- PyWhatKit
- Flask-SocketIO

## Instalação

1. Clone este repositório
2. Instale as dependências:
```bash
pip install -r requirements.txt
```

3. Execute o aplicativo:
```bash
python app.py
```

4. Acesse o chat em: http://localhost:5000

## Funcionalidades

- Interface similar ao WhatsApp
- Catálogo de cestas básicas
- Opções de personalização
- Integração com WhatsApp para envio de pedidos
- Sistema de pagamento com múltiplas opções

## Configuração

1. Adicione suas imagens na pasta `static/img`:
   - `logo.png` - Logo da empresa
   - `whatsapp-bg.png` - Background do chat (opcional)

2. Configure o número do WhatsApp da empresa no arquivo `app.py`:
```python
NUMERO_EMPRESA = "seu-numero-aqui"
```

## Observações

- Certifique-se de ter o WhatsApp Web logado no navegador para o envio automático de mensagens
- As imagens de fundo e logo devem ser adicionadas na pasta static/img
